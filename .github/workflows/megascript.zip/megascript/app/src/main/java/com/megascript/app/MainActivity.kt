package com.megascript.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object Mega {
    init { System.loadLibrary("megascript") }
    external fun run(code: ByteArray): ByteArray
}

private val SAMPLE = """# megascript 0.1
def fat(n):
    if n <= 1:
        return 1
    return n * fat(n - 1)

for i in range(1, 6):
    print("fat", i, "=", fat(i))

print("2 ** 40 =", 2 ** 40)
print("soma 1..999999 =", fastsum(1, 1000000))
print("mdc(48, 18) =", gcd(48, 18))
"""

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val g = Color.parseColor("#33FF66")
        val d = resources.displayMetrics.density
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val out = TextView(this).apply {
            typeface = Typeface.MONOSPACE; setTextColor(g); textSize = 13f
            text = "megascript 0.1\n"; setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(out) }
        val inp = EditText(this).apply {
            typeface = Typeface.MONOSPACE; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            textSize = 14f; setBackgroundColor(Color.parseColor("#101010")); gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            hint = "# escreva megascript aqui"; setText(SAMPLE); setPadding(16, 16, 16, 16)
        }
        fun btn(t: String) = Button(this).apply {
            text = t; setTextColor(g); setBackgroundColor(Color.parseColor("#151515")); isAllCaps = false
        }
        val bRun = btn("▶ rodar"); val bTab = btn("tab"); val bClr = btn("limpar")
        val row = LinearLayout(this).apply {
            addView(bRun, LinearLayout.LayoutParams(0, WRAP_CONTENT, 2f))
            addView(bTab, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(bClr, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        val p = (10 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); setPadding(p, p, p, p)
            addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            addView(inp, LinearLayout.LayoutParams(MATCH_PARENT, (200 * d).toInt()))
            addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        setContentView(root)

        bTab.setOnClickListener { inp.text.insert(inp.selectionStart.coerceAtLeast(0), "    ") }
        bClr.setOnClickListener { out.text = "megascript 0.1\n" }
        bRun.setOnClickListener {
            val code = inp.text.toString()
            out.append("\n>>> rodar\n")
            bRun.isEnabled = false
            Thread(null, Runnable {
                val res = String(Mega.run(code.toByteArray()), Charsets.UTF_8)
                runOnUiThread {
                    out.append(res)
                    if (res.isNotEmpty() && !res.endsWith("\n")) out.append("\n")
                    bRun.isEnabled = true
                    scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                }
            }, "mega", 16L shl 20).start()
        }
    }
}
