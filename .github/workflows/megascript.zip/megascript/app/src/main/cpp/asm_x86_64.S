# megascript - nucleo rapido em assembly x86-64 (AT&T)
.text

.globl ms_asm_ipow
.type ms_asm_ipow, @function
ms_asm_ipow:
    movq $1, %rax
1:  testq %rsi, %rsi
    jz 3f
    testq $1, %rsi
    jz 2f
    imulq %rdi, %rax
2:  imulq %rdi, %rdi
    shrq $1, %rsi
    jmp 1b
3:  ret

.globl ms_asm_sumrange
.type ms_asm_sumrange, @function
ms_asm_sumrange:
    xorq %rax, %rax
    cmpq %rdi, %rsi
    jle 1f
    movq %rsi, %rax
    subq %rdi, %rax
    leaq -1(%rdi,%rsi), %rdx
    imulq %rdx, %rax
    sarq $1, %rax
1:  ret

.globl ms_asm_gcd
.type ms_asm_gcd, @function
ms_asm_gcd:
1:  testq %rsi, %rsi
    jz 2f
    movq %rdi, %rax
    xorq %rdx, %rdx
    divq %rsi
    movq %rsi, %rdi
    movq %rdx, %rsi
    jmp 1b
2:  movq %rdi, %rax
    ret

.section .note.GNU-stack,"",@progbits
