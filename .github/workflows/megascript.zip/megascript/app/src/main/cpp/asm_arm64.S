// megascript - nucleo rapido em assembly ARM64
.text

// long ms_asm_ipow(long base, long exp)  -- exponenciacao por quadrados
.global ms_asm_ipow
.type ms_asm_ipow, %function
ms_asm_ipow:
    mov x2, #1
1:  cbz x1, 3f
    tbz x1, #0, 2f
    mul x2, x2, x0
2:  mul x0, x0, x0
    lsr x1, x1, #1
    b 1b
3:  mov x0, x2
    ret

// long ms_asm_sumrange(long a, long b)  -- soma de a ate b-1 (formula fechada)
.global ms_asm_sumrange
.type ms_asm_sumrange, %function
ms_asm_sumrange:
    cmp x1, x0
    b.le 1f
    sub x2, x1, x0
    add x3, x0, x1
    sub x3, x3, #1
    mul x0, x2, x3
    asr x0, x0, #1
    ret
1:  mov x0, #0
    ret

// long ms_asm_gcd(unsigned long a, unsigned long b)  -- Euclides
.global ms_asm_gcd
.type ms_asm_gcd, %function
ms_asm_gcd:
1:  cbz x1, 2f
    udiv x2, x0, x1
    msub x2, x2, x1, x0
    mov x0, x1
    mov x1, x2
    b 1b
2:  ret
