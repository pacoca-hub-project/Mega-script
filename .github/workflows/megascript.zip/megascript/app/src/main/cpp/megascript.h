#ifndef MEGASCRIPT_H
#define MEGASCRIPT_H
/* roda o codigo e devolve a saida (malloc; quem chama faz free) */
char *ms_run(const char *src);
#endif
