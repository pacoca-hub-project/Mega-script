#include <jni.h>
#include <cstdlib>
#include <cstring>
extern "C" {
#include "megascript.h"
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_megascript_app_Mega_run(JNIEnv *env, jobject, jbyteArray code) {
    jsize n = env->GetArrayLength(code);
    char *src = (char *)malloc((size_t)n + 1);
    env->GetByteArrayRegion(code, 0, n, (jbyte *)src);
    src[n] = 0;
    char *out = ms_run(src);
    free(src);
    jsize m = (jsize)strlen(out);
    jbyteArray r = env->NewByteArray(m);
    env->SetByteArrayRegion(r, 0, m, (const jbyte *)out);
    free(out);
    return r;
}
